# RIDZX WA PROTECT

Starter project Android bertema hitam-neon hijau.

## Build APK dari HP melalui GitHub Actions
1. Buat repository GitHub baru bernama `RIDZX-WA-PROTECT`.
2. Upload semua file dan folder dari proyek ini (jangan upload ZIP saja).
3. Pastikan folder `.github/workflows` ikut terunggah.
4. Buka tab Actions dan jalankan workflow `Build RIDZX WA PROTECT APK`.
5. Jika build sukses, buka hasil run dan unduh artifact `RIDZX-WA-PROTECT-APK`.
6. Ekstrak ZIP artifact, lalu instal `app-debug.apk`.

Aplikasi ini berisi panduan keamanan saja; tidak dapat menjamin nomor kebal pembatasan dan tidak melewati sistem WhatsApp.
