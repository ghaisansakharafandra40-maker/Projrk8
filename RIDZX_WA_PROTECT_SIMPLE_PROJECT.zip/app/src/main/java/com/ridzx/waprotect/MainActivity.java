package com.ridzx.waprotect;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int bg=0xFF07110B, panel=0xFF101D15, green=0xFF7CFF6B, white=0xFFF2FFF3, muted=0xFF9CB0A0;
    LinearLayout root;
    public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView sc=new ScrollView(this); sc.setBackgroundColor(bg); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(18,22,18,28); sc.addView(root); setContentView(sc);
        TextView brand=t("⬡",34,green,true); brand.setGravity(Gravity.CENTER); add(brand,72,72);
        TextView title=t("RIDZX WA PROTECT",24,white,true); title.setGravity(Gravity.CENTER); add(title,-1,-2);
        TextView sub=t("WHATSAPP SECURITY COMPANION · V1.0",11,green,true); sub.setGravity(Gravity.CENTER); add(sub,-1,-2);
        card("DASHBOARD","Jaga akun. Tetap waspada.","Panduan praktis untuk meningkatkan keamanan WhatsApp. Aplikasi ini tidak menjamin nomor kebal blokir.");
        LinearLayout c=box(); c.addView(t("CHECKLIST KEAMANAN",17,green,true));
        String[] tasks={"Aktifkan verifikasi dua langkah","Tambahkan email pemulihan yang aman","Jangan bagikan kode OTP atau PIN","Periksa perangkat tertaut","Gunakan WhatsApp resmi dan terbaru","Tinjau pengaturan privasi"};
        for(String s:tasks){CheckBox cb=new CheckBox(this); cb.setText(s); cb.setTextColor(white); cb.setButtonTintList(android.content.res.ColorStateList.valueOf(green)); c.addView(cb);}
        root.addView(c,lp(0,12));
        card("VERIFIKASI DUA LANGKAH","WhatsApp → Setelan → Akun → Verifikasi dua langkah.","Aktifkan PIN tambahan dan tambahkan email pemulihan jika tersedia.");
        card("AKUN DIBATASI","Ikuti petunjuk peninjauan resmi di aplikasi.","Hindari pesan massal, otomatisasi tidak resmi, dan aplikasi WhatsApp modifikasi. Jangan berikan OTP kepada siapa pun.");
        card("PERBAIKI ERROR","Periksa koneksi dan pembaruan aplikasi.","Mulai ulang aplikasi dan HP, periksa ruang penyimpanan, lalu perbarui WhatsApp dari Google Play.");
        card("PERANGKAT TERTAUT","WhatsApp → Perangkat tertaut.","Keluar dari sesi atau perangkat yang tidak dikenal.");
        TextView foot=t("PANDUAN KEAMANAN · BUKAN ALAT BYPASS",10,muted,true); foot.setGravity(Gravity.CENTER); add(foot,-1,-2);
    }
    void card(String h,String a,String d){LinearLayout c=box(); c.addView(t(h,12,green,true)); TextView x=t(a,19,white,true); x.setPadding(0,10,0,5); c.addView(x); c.addView(t(d,13,muted,false)); root.addView(c,lp(0,12));}
    LinearLayout box(){LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(16,16,16,16); GradientDrawable gd=new GradientDrawable(); gd.setColor(panel); gd.setCornerRadius(22); gd.setStroke(1,0xFF23382A); l.setBackground(gd); return l;}
    TextView t(String s,int size,int color,boolean bold){TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); v.setLineSpacing(3,1); return v;}
    void add(View v,int w,int h){root.addView(v,new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h)));}
    LinearLayout.LayoutParams lp(int w,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(bottom);return p;}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
}
